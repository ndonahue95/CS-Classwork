#include "mysort.h"
#include <alloca.h>
#include <assert.h>
#include <string.h>
#include <stdlib.h>



/* Compare two integer numbers*/
int compareInt( void * a, void * b )
{
  return *(int*)a - *(int*) b;
}



// Compare students by name 
// Hint: use strcmp 
int compareStudentByName( void * a, void * b )
{
  Student * sa = (Student *) a;
  Student * sb = (Student *) b;

  // Please complete this function 
   
}





  /* Compare students by grade first.
     return 1 if grade a is larger than grade b
     return -1 if grade a is less than grade b
     if grades are the same then 
     compare alphabetically
  */ 

int compareStudentByGrade( void * a, void * b )
{

  // Please complete this function 
  return 0;
}




//
// Sort an array of element of any type
// it uses "compFunc" to sort the elements.
// The elements are sorted such as:
//
// if ascending != 0
//   compFunc( array[ i ], array[ i+1 ] ) <= 0
// else
//   compFunc( array[ i ], array[ i+1 ] ) >= 0
//
// See test_sort to see how to use mysort.
//
void mysort( int n,                      // Number of elements
	     int elementSize,            // Size of each element
	     void * array,               // Pointer to an array
	     int ascending,              // 0 -> descending; 1 -> ascending
	     CompareFunction compFunc )  // Comparison function.
{
	// Please complete this function 
}

