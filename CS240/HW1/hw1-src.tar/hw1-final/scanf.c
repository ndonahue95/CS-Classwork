#include <stdio.h>
	
int main(){
	char name[100];
	int age;
	long number;
	printf("Enter your name: ");

	/*scan string from stdin and store it in variable name*/


	printf("Enter your age: ");

	/*scan age from stdin and store it in variable age*/


	printf("Enter your phone number: ");

	/*scan phone number from stdin and store it in number*/


	printf("\n");
	printf("Your name is: %s\n", name);
	printf("Your age is: %d\n", age);
	printf("Your phone number is %ld\n", number);
	return 0;
}
