#include <stdio.h>
	
int main(){
	int num1 = 4;
	int num2 = 67;
	char letter = 'y';
	double decimal = 56.72;
	char * word = "CS240 is really fun";
	/*Print "I am about to print the values of variables\n"*/

	/*Print "The value of num1 is %d and the value of num2 is %d\n"*/

	/*Print "The value of letter is %c\n"*/

	/*Print "The value of decimal is %lf\n"*/

	/*Print "The value of word is %s\n"*/

	/*Print "\"This is a quote\" and '\\' is a slash\n"*/

	return 0;
}
