// do not modify the line after the line after next
// do not modify the line after next
// do not modify the next line
#include "../lib/imageio.h"

int main(int argc, char* argv[])
{
	// TODO
	// Step 1: Load original image
	// Step 2: Negate it
	// Step 3: Save to file
	// Step 4: Finalization
	return 0;
}