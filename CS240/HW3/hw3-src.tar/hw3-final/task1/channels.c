// do not modify the line after the line after next
// do not modify the line after next
// do not modify the next line
#include "../lib/imageio.h"

int main(int argc, char* argv[])
{
	// TODO
	// Step 1: Load original image
	// Step 2: Separate channels
	// Step 3: Save each channels to three files
	// Step 4: Finalization
	return 0;
}